from .Dds_rs import *

__doc__ = Dds_rs.__doc__
if hasattr(Dds_rs, "__all__"):
    __all__ = Dds_rs.__all__